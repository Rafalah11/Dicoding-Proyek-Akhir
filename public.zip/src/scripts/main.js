// import App from "./pages/app.js";

// document.addEventListener("DOMContentLoaded", () => {
//   console.log("Main.js: Initializing App");
//   const app = new App({
//     navigationDrawer: document.getElementById("navigation-drawer"),
//     drawerButton: document.getElementById("drawer-button"),
//     content: document.getElementById("main-content"),
//   });
//   app.renderPage();
// });
